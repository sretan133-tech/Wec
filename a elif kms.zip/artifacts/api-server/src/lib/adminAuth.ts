import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import type { Request, RequestHandler, Response } from "express";

const COOKIE_NAME = "elif_admin_session";
const SESSION_MAX_AGE_MS = 8 * 60 * 60 * 1000;
const loginAttempts = new Map<string, { failures: number; blockedUntil: number }>();

function getSessionSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    throw new Error("SESSION_SECRET must be configured.");
  }
  return secret;
}

function signSession(payload: string): string {
  return createHmac("sha256", getSessionSecret()).update(payload).digest("base64url");
}

function safeEquals(left: string, right: string): boolean {
  const leftHash = createHash("sha256").update(left).digest();
  const rightHash = createHash("sha256").update(right).digest();
  return timingSafeEqual(leftHash, rightHash);
}

export function isAdminSession(req: Request): boolean {
  const token = req.cookies?.[COOKIE_NAME];
  if (typeof token !== "string") return false;

  const [issuedAtText, nonce, signature, ...extra] = token.split(".");
  if (!issuedAtText || !nonce || !signature || extra.length > 0) return false;

  const issuedAt = Number(issuedAtText);
  if (!Number.isSafeInteger(issuedAt)) return false;
  if (Date.now() - issuedAt > SESSION_MAX_AGE_MS || issuedAt > Date.now() + 60_000) {
    return false;
  }

  const payload = `${issuedAtText}.${nonce}`;
  return safeEquals(signature, signSession(payload));
}

export function setAdminSessionCookie(res: Response): void {
  const issuedAt = Date.now().toString();
  const nonce = randomBytes(24).toString("base64url");
  const payload = `${issuedAt}.${nonce}`;
  res.cookie(COOKIE_NAME, `${payload}.${signSession(payload)}`, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: SESSION_MAX_AGE_MS,
  });
}

export function clearAdminSessionCookie(res: Response): void {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
  });
}

export function verifyAdminCredentials(username: string, password: string): boolean {
  const expectedUsername = process.env.ELIF_ADMIN_USERNAME;
  const expectedPassword = process.env.ELIF_ADMIN_PASSWORD;
  if (!expectedUsername || !expectedPassword) return false;
  return safeEquals(username, expectedUsername) && safeEquals(password, expectedPassword);
}

export function isLoginRateLimited(ip: string): boolean {
  const state = loginAttempts.get(ip);
  if (!state) return false;
  if (state.blockedUntil > Date.now()) return true;
  if (state.blockedUntil !== 0 && state.blockedUntil <= Date.now()) {
    loginAttempts.delete(ip);
    return false;
  }
  return state.failures >= 5;
}

export function recordLoginFailure(ip: string): void {
  const current = loginAttempts.get(ip) ?? { failures: 0, blockedUntil: 0 };
  current.failures += 1;
  if (current.failures >= 5) {
    current.blockedUntil = Date.now() + 15 * 60 * 1000;
  }
  loginAttempts.set(ip, current);
}

export function clearLoginFailures(ip: string): void {
  loginAttempts.delete(ip);
}

export const requireAdmin: RequestHandler = (req, res, next) => {
  if (!isAdminSession(req)) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
};
