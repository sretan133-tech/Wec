import { count, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  AdminLoginBody,
  AdminLoginResponse,
  AdminLogoutResponse,
  CreateFabricBody,
  CreateFabricResponse,
  DeleteFabricParams,
  DeleteFabricResponse,
  GetAdminDashboardResponse,
  GetAdminSessionResponse,
  ListAdminFabricsResponse,
  UpdateFabricBody,
  UpdateFabricParams,
  UpdateFabricResponse,
} from "@workspace/api-zod";
import { analyticsCountersTable, db, fabricsTable } from "@workspace/db";
import {
  clearAdminSessionCookie,
  clearLoginFailures,
  isAdminSession,
  isLoginRateLimited,
  recordLoginFailure,
  requireAdmin,
  setAdminSessionCookie,
  verifyAdminCredentials,
} from "../lib/adminAuth";

const router: IRouter = Router();

async function readCounter(key: string): Promise<number> {
  const [row] = await db
    .select({ count: analyticsCountersTable.count })
    .from(analyticsCountersTable)
    .where(eq(analyticsCountersTable.key, key))
    .limit(1);
  return row?.count ?? 0;
}

router.post("/admin/login", (req, res): void => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const ip = req.ip || "unknown";
  if (isLoginRateLimited(ip)) {
    res.status(429).json({ error: "Çok fazla başarısız deneme. Lütfen daha sonra tekrar deneyin." });
    return;
  }

  if (!verifyAdminCredentials(parsed.data.username, parsed.data.password)) {
    recordLoginFailure(ip);
    res.status(401).json({ error: "Kullanıcı adı veya şifre hatalı." });
    return;
  }

  clearLoginFailures(ip);
  setAdminSessionCookie(res);
  res.json(AdminLoginResponse.parse({ authenticated: true }));
});

router.get("/admin/session", (req, res): void => {
  res.json(GetAdminSessionResponse.parse({ authenticated: isAdminSession(req) }));
});

router.delete("/admin/session", (_req, res): void => {
  clearAdminSessionCookie(res);
  res.status(204).json(AdminLogoutResponse.parse(undefined));
});

router.get("/admin/fabrics", requireAdmin, async (_req, res): Promise<void> => {
  const fabrics = await db.select().from(fabricsTable).orderBy(desc(fabricsTable.createdAt));
  res.json(ListAdminFabricsResponse.parse(fabrics));
});

router.post("/admin/fabrics", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateFabricBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [fabric] = await db.insert(fabricsTable).values(parsed.data).returning();
  res.status(201).json(CreateFabricResponse.parse(fabric));
});

router.patch("/admin/fabrics/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateFabricParams.safeParse(req.params);
  const parsed = UpdateFabricBody.safeParse(req.body);
  if (!params.success || !parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
    res.status(400).json({
      error: !params.success ? params.error.message : !parsed.success ? parsed.error.message : "No fields to update",
    });
    return;
  }

  const [fabric] = await db
    .update(fabricsTable)
    .set(parsed.data)
    .where(eq(fabricsTable.id, params.data.id))
    .returning();
  if (!fabric) {
    res.status(404).json({ error: "Fabric not found" });
    return;
  }
  res.json(UpdateFabricResponse.parse(fabric));
});

router.delete("/admin/fabrics/:id", requireAdmin, async (req, res): Promise<void> => {
  const params = DeleteFabricParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [fabric] = await db
    .delete(fabricsTable)
    .where(eq(fabricsTable.id, params.data.id))
    .returning({ id: fabricsTable.id });
  if (!fabric) {
    res.status(404).json({ error: "Fabric not found" });
    return;
  }
  res.status(204).end();
});

router.get("/admin/dashboard", requireAdmin, async (_req, res): Promise<void> => {
  const [[fabricStats], totalVisits, totalCartAdditions, checkoutAttempts] =
    await Promise.all([
      db
        .select({ activeFabrics: count() })
        .from(fabricsTable)
        .where(eq(fabricsTable.active, true)),
      readCounter("total_visits"),
      readCounter("total_cart_additions"),
      readCounter("checkout_attempts"),
    ]);

  res.json(
    GetAdminDashboardResponse.parse({
      totalVisits,
      totalCartAdditions,
      checkoutAttempts,
      completedOrders: 0,
      activeFabrics: fabricStats?.activeFabrics ?? 0,
    }),
  );
});

export default router;
