import { Router, type IRouter } from "express";
import adminRouter from "./admin";
import fabricsRouter from "./fabrics";
import healthRouter from "./health";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(fabricsRouter);
router.use(adminRouter);
router.use(storageRouter);

export default router;
