import { and, desc, eq, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateFabricBody,
  CreateFabricResponse,
  ListAdminFabricsResponse,
  ListPublicFabricsResponse,
  RecordCartAdditionBody,
  RecordCheckoutAttemptResponse,
  RecordVisitResponse,
  UpdateFabricBody,
  UpdateFabricParams,
  UpdateFabricResponse,
} from "@workspace/api-zod";
import { analyticsCountersTable, db, fabricsTable } from "@workspace/db";

const router: IRouter = Router();

async function incrementCounter(key: string, amount = 1): Promise<void> {
  await db
    .insert(analyticsCountersTable)
    .values({ key, count: amount })
    .onConflictDoUpdate({
      target: analyticsCountersTable.key,
      set: { count: sql`${analyticsCountersTable.count} + ${amount}` },
    });
}

router.get("/fabrics", async (_req, res): Promise<void> => {
  const fabrics = await db
    .select()
    .from(fabricsTable)
    .where(eq(fabricsTable.active, true))
    .orderBy(desc(fabricsTable.createdAt));
  res.json(ListPublicFabricsResponse.parse(fabrics));
});

router.post("/analytics/visit", async (_req, res): Promise<void> => {
  await incrementCounter("total_visits");
  res.status(204).end();
});

router.post("/analytics/cart-add", async (req, res): Promise<void> => {
  const parsed = RecordCartAdditionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [fabric] = await db
    .select({ id: fabricsTable.id })
    .from(fabricsTable)
    .where(and(eq(fabricsTable.id, parsed.data.fabricId), eq(fabricsTable.active, true)))
    .limit(1);
  if (!fabric) {
    res.status(404).json({ error: "Fabric not found" });
    return;
  }

  await incrementCounter("total_cart_additions", parsed.data.quantity);
  res.status(204).end();
});

router.post("/analytics/checkout-attempt", async (_req, res): Promise<void> => {
  await incrementCounter("checkout_attempts");
  res.status(204).json(RecordCheckoutAttemptResponse.parse(undefined));
});

export default router;
