import { type ReactNode, createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft, ArrowRight, Check, CircleHelp, Eye, LogOut, MapPin, Minus, Plus,
  Search, ShieldCheck, ShoppingBag, ShoppingBasket, Sparkles, Store, Trash2,
  WalletCards, X,
  Pencil, PackagePlus, MessageCircle, RefreshCw,
} from 'lucide-react';
import {
  useListPublicFabrics, getListPublicFabricsQueryKey, useRecordVisit,
  useRecordCartAddition, useRecordCheckoutAttempt, useAdminLogin,
  useGetAdminSession, getGetAdminSessionQueryKey, useAdminLogout,
  useListAdminFabrics, getListAdminFabricsQueryKey, useCreateFabric,
  useUpdateFabric, useDeleteFabric, useGetAdminDashboard,
  getGetAdminDashboardQueryKey, useRequestUploadUrl,
} from '@workspace/api-client-react';
import type { Fabric as FabricRecord, FabricInput } from '@workspace/api-client-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { demoCatalog, inferFabricCategory, type CatalogFabric } from './catalog-data';

const queryClient = new QueryClient();
const STORE_ADDRESS = 'Elif Kumaş, İstanbul, Esenyurt, İnönü Mahallesi, 354. Sokak';
const WHATSAPP_URL = `https://wa.me/905300860936?text=${encodeURIComponent('Merhaba 😊, Elif Kumaş sitesini görüp geldim. Kumaş satın almak istiyorum. 🧵')}`;
const MAP_URL = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(STORE_ADDRESS)}`;
const fallbackImages = ['/fabric-olive.png', '/fabric-terracotta.png', '/fabric-teal.png'];

type CartLine = { fabricId: number; quantity: number };
type CartContextValue = { lines: CartLine[]; add: (id: number) => void; change: (id: number, delta: number) => void; remove: (id: number) => void; clear: () => void; quantity: number };
const CartContext = createContext<CartContextValue | null>(null);

function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error('CartProvider is missing');
  return value;
}

function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(() => {
    try {
      const saved = localStorage.getItem('elif-kumas-cart-v1');
      return saved ? JSON.parse(saved) as CartLine[] : [];
    } catch { return []; }
  });
  useEffect(() => {
    localStorage.setItem('elif-kumas-cart-v1', JSON.stringify(lines));
  }, [lines]);
  const add = (id: number) => setLines((current) => {
    const line = current.find((item) => item.fabricId === id);
    return line ? current.map((item) => item.fabricId === id ? { ...item, quantity: Math.min(item.quantity + 1, 99) } : item) : [...current, { fabricId: id, quantity: 1 }];
  });
  const change = (id: number, delta: number) => setLines((current) => current.flatMap((line) => line.fabricId !== id ? [line] : line.quantity + delta <= 0 ? [] : [{ ...line, quantity: Math.min(line.quantity + delta, 99) }]));
  const remove = (id: number) => setLines((current) => current.filter((line) => line.fabricId !== id));
  const clear = () => setLines([]);
  const quantity = lines.reduce((total, line) => total + line.quantity, 0);
  return <CartContext.Provider value={{ lines, add, change, remove, clear, quantity }}>{children}</CartContext.Provider>;
}

function Brand() {
  return <div className="brand" data-testid="brand-elif-kumas" aria-label="Elif Kumaş">
    <span className="brand-mark" aria-hidden="true">E</span>
    <span><span className="brand-name">Elif Kumaş</span><span className="brand-subtitle">Dokusu güzel, ömrü uzun</span></span>
  </div>;
}

function Header() {
  const { quantity } = useCart();
  return <header className="site-header">
    <div className="header-inner">
      <Link href="/" className="brand" data-testid="link-home"><Brand /></Link>
      <nav className="nav-links" aria-label="Ana menü">
        <Link href="/">Kumaşlar</Link>
        <a href="#magaza">Mağazamız</a>
      </nav>
      <div className="header-actions">
        <Link href="/cart" className="cart-link" data-testid="link-cart" aria-label={`Sepetim, ${quantity} ürün`}>
          <ShoppingBag size={16} /><span>Sepetim</span><span className="cart-count" data-testid="text-cart-count">{quantity}</span>
        </Link>
      </div>
    </div>
  </header>;
}

function Footer() {
  return <footer className="site-footer">
    <div className="page-wrap footer-inner">
      <Brand />
      <p className="footer-note">Kumaşın güzeli, dokununca anlaşılır. · {STORE_ADDRESS}</p>
      <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" data-testid="link-footer-whatsapp" className="footer-note">Bize ulaşın</a>
    </div>
  </footer>;
}

function FabricPhoto({ fabric, index = 0, alt }: { fabric?: FabricRecord; index?: number; alt: string }) {
  const [failed, setFailed] = useState(false);
  const src = fabric?.imageUrl && !failed ? fabric.imageUrl : fallbackImages[index % fallbackImages.length];
  return <img src={src} alt={alt} onError={() => setFailed(true)} loading="lazy" />;
}

function Home() {
  const { add } = useCart();
  const visit = useRecordVisit();
  const addToCart = useRecordCartAddition();
  const visitTracked = useRef(false);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('Tümü');
  const fabricsQuery = useListPublicFabrics();
  const fabrics = fabricsQuery.data ?? [];
  const usingDemoCatalog = !fabricsQuery.isLoading && !fabricsQuery.isError && fabrics.length === 0;
  const catalog = useMemo<CatalogFabric[]>(() => usingDemoCatalog ? demoCatalog : fabrics.map((fabric) => ({ ...fabric, category: inferFabricCategory(fabric) })), [fabrics, usingDemoCatalog]);
  const categories = useMemo(() => ['Tümü', ...Array.from(new Set(catalog.map((fabric) => fabric.category)))], [catalog]);
  useEffect(() => {
    if (!visitTracked.current) {
      visitTracked.current = true;
      visit.mutate();
    }
  }, []);
  useEffect(() => {
    if (!categories.includes(activeCategory)) setActiveCategory('Tümü');
  }, [categories, activeCategory]);
  const filtered = useMemo(() => catalog.filter((fabric) => {
    const matchesCategory = activeCategory === 'Tümü' || fabric.category === activeCategory;
    const matchesSearch = `${fabric.name} ${fabric.description} ${fabric.category}`.toLocaleLowerCase('tr-TR').includes(search.toLocaleLowerCase('tr-TR'));
    return matchesCategory && matchesSearch;
  }), [catalog, activeCategory, search]);
  const addFabric = (fabric: FabricRecord) => {
    add(fabric.id);
    if (!(fabric as CatalogFabric).isSample) addToCart.mutate({ data: { fabricId: fabric.id, quantity: 1 } });
  };
  return <div className="site-shell">
    <Header />
    <main>
      <section className="page-wrap hero" aria-labelledby="hero-title">
        <div className="hero-copy">
          <div className="eyebrow">Elinize yakışan dokular</div>
          <h1 id="hero-title">Güzel şeyler<br />iyi <em>dokunur.</em></h1>
          <p>Günlük hayatınıza eşlik edecek, özenle seçilmiş kumaşları keşfedin. Dokusu, rengi ve kalitesiyle içinize sinen parça burada.</p>
          <div className="hero-ctas">
            <a className="button button-primary" href="#kumaslar" data-testid="button-explore-fabrics">Kumaşları keşfet <ArrowRight size={16} /></a>
            <a className="button button-outline" href={MAP_URL} target="_blank" rel="noreferrer" data-testid="button-store-location"><MapPin size={16} /> Mağazamıza uğrayın</a>
          </div>
        </div>
        <div className="hero-art" aria-label="Elif Kumaş koleksiyonundan kumaşlar">
          <div className="fabric-thread" aria-hidden="true" />
          <div className="hero-photo"><img src="/atelier-hero.png" alt="Yumuşak ışıkta serilmiş dokuma kumaşlar" /></div>
          <div className="hero-stamp"><div><strong>Seçkin</strong><span>dokular<br />iyi hisler</span></div></div>
        </div>
      </section>
      <section className="promise-strip" aria-label="Elif Kumaş ayrıcalıkları">
        <div className="page-wrap promise-inner">
          <div className="promise"><Sparkles size={16} /> Özenle seçilmiş koleksiyon</div>
          <div className="promise"><ShieldCheck size={16} /> Güvenle alışveriş</div>
          <div className="promise"><Store size={16} /> Gerçek mağaza, gerçek dokunuş</div>
        </div>
      </section>
      <section className="page-wrap catalog-section" id="kumaslar" aria-labelledby="catalog-heading">
        <div className="section-heading">
          <div><div className="eyebrow">Koleksiyon</div><h2 id="catalog-heading">Dokunmayı bekleyenler</h2><p>İlham veren desenler, güzel işçilik ve her projeye uygun bir doku.</p></div>
          <label className="search-box"><Search size={17} /><input aria-label="Kumaşlarda ara" placeholder="Kumaşlarda ara..." value={search} onChange={(event) => setSearch(event.target.value)} data-testid="input-search-fabrics" /></label>
        </div>
        {!fabricsQuery.isLoading && !fabricsQuery.isError && <div className="catalog-filter-row">
          <div className="category-tabs" role="tablist" aria-label="Kumaş kategorileri">
            {categories.map((category, index) => {
              const count = category === 'Tümü' ? catalog.length : catalog.filter((fabric) => fabric.category === category).length;
              const selected = activeCategory === category;
              return <button key={category} id={`catalog-tab-${index}`} type="button" role="tab" aria-selected={selected} tabIndex={selected ? 0 : -1} className={`category-tab${selected ? ' active' : ''}`} onClick={() => setActiveCategory(category)} onKeyDown={(event) => {
                const direction = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
                if (!direction) return;
                event.preventDefault();
                const nextIndex = (index + direction + categories.length) % categories.length;
                setActiveCategory(categories[nextIndex]);
                document.getElementById(`catalog-tab-${nextIndex}`)?.focus();
              }} data-testid={`tab-category-${category.replaceAll(' ', '-').toLocaleLowerCase('tr-TR')}`}>
                {category}<span>{count}</span>
              </button>;
            })}
          </div>
          <span className="catalog-result-count">{filtered.length} kumaş</span>
        </div>}
        {usingDemoCatalog && <p className="catalog-demo-note"><Sparkles size={14} /> Örnek koleksiyon · Ürün adları ve fiyatlar taslak amaçlıdır.</p>}
        {fabricsQuery.isLoading ? <div className="loading-grid" aria-label="Kumaşlar yükleniyor"><div className="skeleton" /><div className="skeleton" /><div className="skeleton" /></div> :
          fabricsQuery.isError ? <div className="notice-state" role="alert"><CircleHelp size={25} /><h3>Koleksiyona şu an ulaşılamıyor</h3><p>Bağlantınızı kontrol edip yeniden deneyin.</p><button className="button button-outline" onClick={() => fabricsQuery.refetch()} data-testid="button-retry-fabrics"><RefreshCw size={15} /> Yeniden dene</button></div> :
            filtered.length === 0 ? <div className="empty-state" data-testid="empty-fabrics"><h3>{search ? 'Aradığınız kumaşı bulamadık' : `${activeCategory} kategorisinde kumaş yok`}</h3><p>{search ? 'Farklı bir kelimeyle yeniden arayabilirsiniz.' : 'Başka bir kategori seçerek koleksiyona göz atabilirsiniz.'}</p></div> :
              <div className="fabric-grid" key={activeCategory} role="tabpanel" aria-label={`${activeCategory} kumaşları`}>
                {filtered.map((fabric, index) => <article className="fabric-card" key={fabric.id} data-testid={`card-fabric-${fabric.id}`} style={{ animationDelay: `${Math.min(index * 55, 385)}ms` }}>
                  <div className="fabric-image"><FabricPhoto fabric={fabric} index={index} alt={`${fabric.name} kumaş dokusu`} /><span className="swatch-label">{fabric.category}</span></div>
                  <div className="fabric-info">
                    <div className="fabric-info-top"><h3 data-testid={`text-fabric-name-${fabric.id}`}>{fabric.name}</h3><span className="price">{formatPrice(fabric.price)}</span></div>
                    <p>{fabric.description || 'Özenle seçilmiş, güzel dokulu kumaş.'}</p>
                    <div className="fabric-bottom"><span className="unit-label">Metre fiyatı</span><button className="add-button" onClick={() => addFabric(fabric)} data-testid={`button-add-cart-${fabric.id}`}><Plus size={14} /> Sepete ekle</button></div>
                  </div>
                </article>)}
              </div>}
      </section>
      <section className="faq-section" id="sikca-sorulanlar" aria-labelledby="faq-heading">
        <div className="page-wrap faq-layout">
          <div className="faq-intro">
            <div className="eyebrow">Merak ettikleriniz</div>
            <h2 id="faq-heading">Sıkça sorulanlar</h2>
            <p>Alışveriş öncesi aklınızdaki birkaç soruya kısa yanıtlar.</p>
            <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="faq-contact" data-testid="link-faq-whatsapp">Başka bir sorunuz mu var? Bize yazın <ArrowRight size={14} /></a>
          </div>
          <div className="faq-list">
            <details className="faq-item" data-testid="faq-metre-fiyati">
              <summary><span>Metre fiyatı ne anlama geliyor?</span><span className="faq-toggle" aria-hidden="true">+</span></summary>
              <p>Ürünlerde görünen fiyat 1 metre kumaş içindir. Sepetinizdeki miktarı metre olarak artırıp azaltabilirsiniz.</p>
            </details>
            <details className="faq-item" data-testid="faq-sepet-indirimi">
              <summary><span>Sepet indirimi nasıl uygulanıyor?</span><span className="faq-toggle" aria-hidden="true">+</span></summary>
              <p>Toplam kumaş miktarı 3 metreye ulaştığında ara toplam üzerinden %2 indirim otomatik hesaplanır.</p>
            </details>
            <details className="faq-item" data-testid="faq-checkout">
              <summary><span>İnternetten satın alma yapabilir miyim?</span><span className="faq-toggle" aria-hidden="true">+</span></summary>
              <p>Online satın alma şu an bakımda. Bu sistem şu an bakımdadır. Satın alımlar için mağazamızı ziyaret etmeye ne dersiniz?</p>
            </details>
            <details className="faq-item" data-testid="faq-store-contact">
              <summary><span>Mağazanız nerede, size nasıl ulaşabilirim?</span><span className="faq-toggle" aria-hidden="true">+</span></summary>
              <p>Elif Kumaş, İstanbul, Esenyurt, İnönü Mahallesi, 354. Sokak adresindeyiz. <a href={MAP_URL} target="_blank" rel="noreferrer">Haritada yol tarifi alın</a> veya <a href={WHATSAPP_URL} target="_blank" rel="noreferrer">WhatsApp’tan bize yazın</a>.</p>
            </details>
          </div>
        </div>
      </section>
      <section className="visit-section" id="magaza">
        <div className="page-wrap visit-inner">
          <div className="visit-copy"><div className="eyebrow">Yakından tanışalım</div><h2>Kumaşı görmeden karar vermeyin.</h2><p>Renkleri gün ışığında görün, dokusuna kendiniz dokunun. Elif Kumaş’ta size yardımcı olmaktan mutluluk duyarız.</p></div>
          <div className="visit-actions">
            <a className="button button-primary" href={MAP_URL} target="_blank" rel="noreferrer" data-testid="button-map"><MapPin size={16} /> Yol tarifi al</a>
            <a className="button button-outline" href={WHATSAPP_URL} target="_blank" rel="noreferrer" data-testid="button-whatsapp"><MessageCircle size={16} /> WhatsApp’tan yazın</a>
          </div>
          <div className="store-map" role="group" aria-label="Elif Kumaş mağaza konumu">
            <svg className="map-art" viewBox="0 0 520 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
              <rect width="520" height="300" fill="#e5e8d9" />
              <path d="M-20 55 150 115 282 72 542 155M-15 255 160 185 330 224 540 137M112 -20 160 90 130 173 220 320M350 -15 315 80 370 155 330 330M-20 160 95 140 185 174 275 142 385 170 550 115" fill="none" stroke="#faf8ee" strokeWidth="20" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M-20 55 150 115 282 72 542 155M-15 255 160 185 330 224 540 137M112 -20 160 90 130 173 220 320M350 -15 315 80 370 155 330 330M-20 160 95 140 185 174 275 142 385 170 550 115" fill="none" stroke="#d4d5c5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M30 15h56v34H30zM208 18h62v35h-62zM414 25h71v42h-71zM32 202h57v38H32zM400 203h68v44h-68zM219 248h47v31h-47z" fill="#d4dfcc" />
              <path d="M168 31h35v24h-35zM385 82h44v29h-44zM64 90h38v28H64zM285 256h34v28h-34z" fill="#d9e3e2" />
              <circle cx="292" cy="150" r="35" fill="#b6c7ae" opacity=".72" />
            </svg>
            <div className="location-card">
              <div className="location-card-brand"><span className="location-mark">E</span><span>MAĞAZAMIZ</span><MapPin size={16} /></div>
              <h3>Elif Kumaş</h3>
              <p>{STORE_ADDRESS}</p>
              <a href={MAP_URL} target="_blank" rel="noreferrer" data-testid="link-map-fallback">Google Haritalar’da aç <ArrowRight size={14} /></a>
              <p className="map-name-alert" role="note"><span className="map-alert-dot" aria-hidden="true" /><span><strong>Bilgilendirme</strong> Google Haritalar’da mağazamız eski adı “Melek Kumaş” ile görünebilir. Güncel adımız <b>Elif Kumaş</b>.</span></p>
            </div>
          </div>
          <a className="store-address" href={MAP_URL} target="_blank" rel="noreferrer" data-testid="link-store-address"><MapPin size={15} /> {STORE_ADDRESS}</a>
        </div>
      </section>
    </main>
    <Footer />
  </div>;
}

function formatPrice(value: number) {
  return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 2 }).format(value);
}

function CartPage() {
  const { lines, change, remove, add, quantity } = useCart();
  const [attempted, setAttempted] = useState(false);
  const checkoutAttempt = useRecordCheckoutAttempt();
  const addToCart = useRecordCartAddition();
  const { data: fabrics = [], isLoading, isError, refetch } = useListPublicFabrics();
  const cartCatalog = useMemo<CatalogFabric[]>(() => !isLoading && !isError && fabrics.length === 0 ? demoCatalog : fabrics.map((fabric) => ({ ...fabric, category: inferFabricCategory(fabric) })), [fabrics, isLoading, isError]);
  const cartRows = lines.map((line) => ({ ...line, fabric: cartCatalog.find((fabric) => fabric.id === line.fabricId) })).filter((line): line is CartLine & { fabric: CatalogFabric } => Boolean(line.fabric));
  const subtotal = cartRows.reduce((sum, line) => sum + line.fabric.price * line.quantity, 0);
  const discount = quantity >= 3 ? subtotal * .02 : 0;
  const addFabric = (fabric: FabricRecord) => {
    add(fabric.id);
    if (!(fabric as CatalogFabric).isSample) addToCart.mutate({ data: { fabricId: fabric.id, quantity: 1 } });
  };
  return <div className="site-shell"><Header /><main className="page-wrap subpage">
    <Link href="/" className="muted" data-testid="link-back-catalog" style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 12, marginBottom: 22 }}><ArrowLeft size={15} /> Kumaşlara dön</Link>
    <h1 className="page-title">Sepetiniz</h1><p className="muted" style={{ margin: '9px 0 0', fontSize: 14 }}>Seçtiklerinize bir göz atın.</p>
    <div className="cart-layout">
      <section className="panel" aria-label="Sepet ürünleri">
        {isLoading ? <div className="loading-grid"><div className="skeleton" /></div> :
          isError ? <div className="notice-state" role="alert"><p>Sepet ürünleri şu an yüklenemedi.</p><button onClick={() => refetch()} className="button button-outline" data-testid="button-retry-cart"><RefreshCw size={15} /> Yeniden dene</button></div> :
            cartRows.length === 0 ? <div className="empty-state" data-testid="empty-cart"><ShoppingBasket size={27} /><h3>Sepetiniz şimdilik boş</h3><p>Size hitap eden kumaşları koleksiyondan seçin.</p><Link href="/" className="button button-primary" data-testid="button-empty-catalog">Koleksiyona göz at <ArrowRight size={15} /></Link></div> :
              cartRows.map((line, index) => <article className="cart-row" key={line.fabricId} data-testid={`cart-row-${line.fabricId}`}>
                <FabricPhoto fabric={line.fabric} index={index} alt={`${line.fabric.name} kumaş`} />
                <div><h3>{line.fabric.name}</h3><p>{formatPrice(line.fabric.price)} / metre</p><div className="qty-controls"><button aria-label={`${line.fabric.name} miktarını azalt`} onClick={() => change(line.fabricId, -1)} data-testid={`button-qty-minus-${line.fabricId}`}><Minus size={13} /></button><span data-testid={`text-qty-${line.fabricId}`}>{line.quantity}</span><button aria-label={`${line.fabric.name} miktarını artır`} onClick={() => change(line.fabricId, 1)} data-testid={`button-qty-plus-${line.fabricId}`}><Plus size={13} /></button></div></div>
                <div style={{ textAlign: 'right' }}><strong>{formatPrice(line.fabric.price * line.quantity)}</strong><br /><button className="remove-button" onClick={() => remove(line.fabricId)} data-testid={`button-remove-${line.fabricId}`} aria-label={`${line.fabric.name} ürününü kaldır`}><Trash2 size={15} /></button></div>
              </article>)}
        <div className="cart-divider" aria-hidden="true"><span>Alışverişe devam</span></div>
        <section className="cart-catalog" aria-labelledby="cart-catalog-title">
          <div className="cart-catalog-heading"><div><h2 id="cart-catalog-title">Satın alınabilecek kumaşlar</h2><p>Güzel dokuları keşfetmeye devam edin.</p></div><Link href="/" data-testid="link-continue-shopping">Tüm koleksiyon <ArrowRight size={14} /></Link></div>
          {isLoading ? <div className="cart-recommendation-grid" aria-label="Kumaşlar yükleniyor"><div className="cart-recommendation-skeleton" /><div className="cart-recommendation-skeleton" /></div> :
            isError ? <div className="catalog-inline-state" role="alert"><span>Kumaş listesi yüklenemedi.</span><button onClick={() => refetch()} data-testid="button-retry-cart-catalog">Yeniden dene</button></div> :
              cartCatalog.length === 0 ? <div className="catalog-inline-state">Şu anda listelenecek kumaş bulunmuyor.</div> :
                <div className="cart-recommendation-grid">
                  {cartCatalog.map((fabric, index) => <article className="cart-recommendation" key={fabric.id} data-testid={`cart-catalog-fabric-${fabric.id}`}>
                    <FabricPhoto fabric={fabric} index={index} alt={`${fabric.name} kumaş dokusu`} />
                    <div className="cart-recommendation-copy"><h3>{fabric.name}</h3><span>{formatPrice(fabric.price)} <small>/ metre</small></span></div>
                    <button className="cart-add-button" onClick={() => addFabric(fabric)} aria-label={`${fabric.name} kumaşından bir metre sepete ekle`} data-testid={`button-cart-add-fabric-${fabric.id}`}><Plus size={14} /></button>
                  </article>)}
                </div>}
        </section>
      </section>
      <aside className="panel" aria-label="Sipariş özeti">
        <h2 style={{ fontFamily: 'var(--app-font-serif)', margin: '0 0 12px', fontSize: 21 }}>Sipariş özeti</h2>
        <div className="summary-line"><span>Toplam ürün</span><strong>{quantity} metre</strong></div>
        <div className="summary-line"><span>Ara toplam</span><strong>{formatPrice(subtotal)}</strong></div>
        {quantity >= 3 ? <div className="summary-line"><span>Sepet indirimi · %2</span><strong>−{formatPrice(discount)}</strong></div> : <p className="discount-note">3 metre ve üzeri alışverişte toplam tutara %2 indirim uygulanır.</p>}
        <div className="summary-line total"><span>Genel toplam</span><strong>{formatPrice(subtotal - discount)}</strong></div>
        <p className="maintenance-note">Online ödeme şu anda kullanılamıyor.</p>
        <button className="button button-primary" style={{ width: '100%', marginTop: 13 }} onClick={() => { checkoutAttempt.mutate(); setAttempted(true); }} data-testid="button-checkout-info"><ShoppingBag size={16} /> Ödemeye geç</button>
        {attempted && <div className="checkout-reveal" role="status" data-testid="status-checkout-maintenance">
          <strong>Online satın alma şu an kapalı</strong>
          <p>Bu sistem şu an bakımdadır. Satın alımlar için mağazamızı ziyaret etmeye ne dersiniz.</p>
          <div className="store-actions">
            <a className="button button-outline" href={MAP_URL} target="_blank" rel="noreferrer" data-testid="button-cart-map"><MapPin size={15} /> Haritada mağazayı aç</a>
            <a className="button button-outline" href={WHATSAPP_URL} target="_blank" rel="noreferrer" data-testid="button-cart-whatsapp"><MessageCircle size={15} /> WhatsApp’tan iletişime geç</a>
          </div>
          <p className="checkout-address"><MapPin size={12} /> {STORE_ADDRESS}</p>
        </div>}
      </aside>
    </div>
  </main><Footer /></div>;
}

function LoginPage() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const login = useAdminLogin();
  const [error, setError] = useState('');
  const queryClient = useQueryClient();
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    login.mutate({ data: { username, password } }, {
      onSuccess: async () => {
        await queryClient.invalidateQueries({ queryKey: getGetAdminSessionQueryKey() });
        setLocation('/admin');
      },
      onError: () => setError('Giriş bilgileri doğrulanamadı. Yeniden deneyin.'),
    });
  };
  return <div className="site-shell"><Header /><main className="page-wrap subpage">
    <div className="login-card">
      <Brand />
      <div className="eyebrow">Yönetici erişimi</div>
      <h1>Hoş geldiniz.</h1>
      <p>Mağaza yönetimine devam etmek için hesabınızla giriş yapın.</p>
      <form className="login-form" onSubmit={submit}>
        <label className="field"><span>Kullanıcı adı</span><input required autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} data-testid="input-admin-username" /></label>
        <label className="field"><span>Şifre</span><input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} data-testid="input-admin-password" /></label>
        {error && <div role="alert" className="login-error" data-testid="status-login-error">{error}</div>}
        <button className="button button-primary" type="submit" disabled={login.isPending} data-testid="button-admin-login">{login.isPending ? 'Giriş yapılıyor…' : 'Güvenli giriş yap'} <ArrowRight size={15} /></button>
      </form>
      <p style={{ fontSize: 10, margin: '17px 0 0', display: 'flex', gap: 6, alignItems: 'center' }}><ShieldCheck size={13} /> Oturumunuz güvenli çerez ile korunur.</p>
    </div>
  </main><Footer /></div>;
}

type FabricFormValue = { name: string; description: string; price: string; imageUrl: string; active: boolean };
const blankFabric: FabricFormValue = { name: '', description: '', price: '', imageUrl: '', active: true };

function FabricModal({ initial, onClose, onSave, pending }: { initial?: FabricRecord; onClose: () => void; onSave: (value: FabricFormValue) => void; pending: boolean }) {
  const [form, setForm] = useState<FabricFormValue>(initial ? { name: initial.name, description: initial.description, price: String(initial.price), imageUrl: initial.imageUrl ?? '', active: initial.active } : blankFabric);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const requestUpload = useRequestUploadUrl();
  const update = (key: keyof FabricFormValue, value: string | boolean) => setForm((current) => ({ ...current, [key]: value }));
  const uploadImage = async (file?: File) => {
    if (!file) return;
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) { setError('Yalnızca JPEG, PNG veya WebP görselleri yükleyebilirsiniz.'); return; }
    if (file.size > 10 * 1024 * 1024) { setError('Görsel boyutu 10 MB sınırını aşamaz.'); return; }
    setError('');
    setUploading(true);
    try {
      const upload = await requestUpload.mutateAsync({ data: { name: file.name, size: file.size, contentType: file.type as 'image/jpeg' | 'image/png' | 'image/webp' } });
      const response = await fetch(upload.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
      if (!response.ok) throw new Error('upload-failed');
      const imageUrl = `/api/storage${upload.objectPath.startsWith('/') ? '' : '/'}${upload.objectPath}`;
      update('imageUrl', imageUrl);
    } catch {
      setError('Görsel yüklenemedi. Lütfen yeniden deneyin.');
    } finally {
      setUploading(false);
    }
  };
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!form.name.trim() || Number(form.price) <= 0) { setError('Ürün adı ve sıfırdan büyük bir fiyat girin.'); return; }
    setError('');
    onSave(form);
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="modal" role="dialog" aria-modal="true" aria-labelledby="fabric-modal-title">
      <div className="modal-head"><div><div className="eyebrow">{initial ? 'Koleksiyonu güncelle' : 'Yeni parça'}</div><h2 id="fabric-modal-title">{initial ? 'Kumaşı düzenle' : 'Kumaş ekle'}</h2></div><button className="icon-button" onClick={onClose} aria-label="Pencereyi kapat" data-testid="button-close-fabric-modal"><X size={16} /></button></div>
      <form onSubmit={submit}>
        <div className="form-grid">
          <label className="field full"><span>Kumaş adı</span><input required maxLength={120} value={form.name} onChange={(event) => update('name', event.target.value)} data-testid="input-fabric-name" /></label>
          <label className="field"><span>Metre fiyatı (₺)</span><input required min="0.01" step="0.01" type="number" value={form.price} onChange={(event) => update('price', event.target.value)} data-testid="input-fabric-price" /></label>
          <label className="field"><span>Görsel bağlantısı</span><input type="text" placeholder="https:// veya /api/storage/…" value={form.imageUrl} onChange={(event) => update('imageUrl', event.target.value)} data-testid="input-fabric-image-url" /></label>
          <label className="field full"><span>Görsel yükle <span className="muted">(JPEG, PNG veya WebP · en fazla 10 MB)</span></span><input type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { void uploadImage(event.target.files?.[0]); event.currentTarget.value = ''; }} data-testid="input-fabric-image-upload" /><span className="muted" role="status" data-testid="status-image-upload">{uploading ? 'Görsel yükleniyor…' : ''}</span></label>
          {form.imageUrl && <div className="image-preview" data-testid="preview-fabric-image"><img src={form.imageUrl} alt="Yüklenen kumaş görseli önizlemesi" /><span>Görsel önizlemesi</span></div>}
          <label className="field full"><span>Açıklama</span><textarea maxLength={1000} value={form.description} onChange={(event) => update('description', event.target.value)} data-testid="input-fabric-description" /></label>
          <label className="toggle-row"><span><strong>Ürün yayında</strong><br /><span className="muted">Aktif kumaşlar katalogda görünür.</span></span><input type="checkbox" checked={form.active} onChange={(event) => update('active', event.target.checked)} data-testid="toggle-fabric-active" /></label>
          {error && <p className="form-error" role="alert">{error}</p>}
        </div>
        <div className="modal-actions"><button type="button" className="button button-outline" onClick={onClose} data-testid="button-cancel-fabric">Vazgeç</button><button className="button button-primary" type="submit" disabled={pending || uploading} data-testid="button-save-fabric">{pending ? 'Kaydediliyor…' : initial ? 'Değişiklikleri kaydet' : 'Kumaşı ekle'}</button></div>
      </form>
    </section>
  </div>;
}

function AdminPage() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const sessionQuery = useGetAdminSession();
  const authenticated = sessionQuery.data?.authenticated === true;
  const fabricsQuery = useListAdminFabrics({ query: { enabled: authenticated, queryKey: getListAdminFabricsQueryKey() } });
  const dashboardQuery = useGetAdminDashboard({ query: { enabled: authenticated, queryKey: getGetAdminDashboardQueryKey() } });
  const create = useCreateFabric();
  const update = useUpdateFabric();
  const removeMutation = useDeleteFabric();
  const logout = useAdminLogout();
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<FabricRecord | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [actionError, setActionError] = useState('');
  const [saved, setSaved] = useState(false);
  const fabrics = fabricsQuery.data ?? [];
  const filtered = useMemo(() => fabrics.filter((fabric) => `${fabric.name} ${fabric.description}`.toLocaleLowerCase('tr').includes(search.toLocaleLowerCase('tr'))), [fabrics, search]);

  useEffect(() => {
    if (!sessionQuery.isLoading && (!sessionQuery.data || !sessionQuery.data.authenticated)) setLocation('/login');
  }, [sessionQuery.isLoading, sessionQuery.data, setLocation]);

  const refreshCatalog = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: getListAdminFabricsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getListPublicFabricsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getGetAdminDashboardQueryKey() }),
    ]);
  };
  const saveFabric = (value: FabricFormValue) => {
    setActionError('');
    setSaved(false);
    const data: FabricInput = { name: value.name.trim(), description: value.description.trim(), price: Number(value.price), imageUrl: value.imageUrl.trim() || null, active: value.active };
    const options = {
      onSuccess: async () => { await refreshCatalog(); setModalOpen(false); setEditing(null); setSaved(true); },
      onError: () => setActionError('Kumaş kaydedilemedi. Lütfen yeniden deneyin.'),
    };
    if (editing) update.mutate({ id: editing.id, data }, options);
    else create.mutate({ data }, options);
  };
  const deleteFabric = (fabric: FabricRecord) => {
    if (!window.confirm(`“${fabric.name}” kumaşını silmek istediğinize emin misiniz?`)) return;
    setActionError('');
    removeMutation.mutate({ id: fabric.id }, {
      onSuccess: () => { void refreshCatalog(); setSaved(true); },
      onError: () => setActionError('Kumaş silinemedi. Lütfen yeniden deneyin.'),
    });
  };
  const signOut = () => logout.mutate(undefined, { onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: getGetAdminSessionQueryKey() }); setLocation('/login'); } });
  if (sessionQuery.isLoading || (!authenticated && !sessionQuery.isError)) return <div className="admin-loading"><div className="skeleton" style={{ height: 150 }} /><div className="loading-grid" style={{ marginTop: 18 }}><div className="skeleton" /><div className="skeleton" /><div className="skeleton" /></div></div>;
  if (sessionQuery.isError) return <div className="page-wrap subpage"><div className="notice-state" role="alert"><h2>Yönetim paneline ulaşılamıyor</h2><button className="button button-outline" onClick={() => sessionQuery.refetch()} data-testid="button-retry-session"><RefreshCw size={15} /> Yeniden dene</button></div></div>;
  if (!authenticated) return null;
  const dashboard = dashboardQuery.data;
  const metricItems = [
    { label: 'Toplam ziyaret', value: dashboard?.totalVisits, icon: Eye },
    { label: 'Sepete ekleme', value: dashboard?.totalCartAdditions, icon: ShoppingBasket },
    { label: 'Satın alma girişimi', value: dashboard?.checkoutAttempts, icon: WalletCards },
    { label: 'Tamamlanan alışveriş', value: dashboard?.completedOrders, icon: Check },
    { label: 'Aktif kumaş', value: dashboard?.activeFabrics, icon: PackagePlus },
  ];
  return <div className="site-shell">
    <header className="site-header"><div className="header-inner"><Link href="/" className="brand" data-testid="link-admin-home"><Brand /></Link><nav className="nav-links"><Link href="/">Mağazayı görüntüle</Link></nav><button className="button button-outline" onClick={signOut} disabled={logout.isPending} data-testid="button-admin-logout"><LogOut size={15} /> Çıkış yap</button></div></header>
    <main className="admin-wrap">
      <div className="admin-top"><div className="admin-title"><small>Elif Kumaş · Yönetim</small><h1>Mağaza özeti</h1><span className="muted" style={{ fontSize: 13 }}>Koleksiyonunuz ve mağaza hareketleri bir arada.</span></div><button className="button button-primary" onClick={() => { setEditing(null); setModalOpen(true); setActionError(''); }} data-testid="button-new-fabric"><Plus size={16} /> Yeni kumaş ekle</button></div>
      <section aria-label="Mağaza metrikleri">
        {dashboardQuery.isLoading ? <div className="metric-grid">{metricItems.map((item) => <div className="skeleton" key={item.label} style={{ height: 112 }} />)}</div> :
          dashboardQuery.isError ? <div className="notice-state" role="alert"><p>Özet verileri yüklenemedi.</p><button className="button button-outline" onClick={() => dashboardQuery.refetch()} data-testid="button-retry-dashboard">Yeniden dene</button></div> :
            <div className="metric-grid">{metricItems.map(({ label, value, icon: Icon }) => <article className="metric-card" key={label} data-testid={`metric-${label.replaceAll(' ', '-')}`}><span className="metric-icon"><Icon size={16} /></span><div className="metric-value">{value ?? 0}</div><div className="metric-label">{label}</div></article>)}</div>}
      </section>
      <section aria-labelledby="fabric-management-heading">
        <div className="manage-head"><h2 id="fabric-management-heading">Kumaş kataloğu</h2><div className="manage-actions"><label className="search-box"><Search size={16} /><input className="admin-search" placeholder="Kumaş ara..." value={search} onChange={(event) => setSearch(event.target.value)} aria-label="Yönetim kataloğunda ara" data-testid="input-admin-search" /></label><span className="muted" style={{ fontSize: 11 }}>{fabrics.length} kayıt</span></div></div>
        {actionError && <p className="login-error" role="alert" data-testid="status-admin-error">{actionError}</p>}
        {saved && <p role="status" className="discount-note" data-testid="status-admin-saved">Değişiklikler kaydedildi.</p>}
        {fabricsQuery.isLoading ? <div className="skeleton" style={{ height: 240 }} /> :
          fabricsQuery.isError ? <div className="notice-state" role="alert"><p>Kumaş listesi yüklenemedi.</p><button onClick={() => fabricsQuery.refetch()} className="button button-outline" data-testid="button-retry-admin-fabrics"><RefreshCw size={15} /> Yeniden dene</button></div> :
            filtered.length === 0 ? <div className="empty-state"><h3>{search ? 'Eşleşen kumaş yok' : 'Kataloğunuzda henüz kumaş bulunmuyor'}</h3><p>{search ? 'Farklı bir arama deneyin.' : 'İlk kumaşınızı ekleyerek başlayın.'}</p></div> :
              <div className="table-wrap"><table className="fabric-table"><thead><tr><th>Kumaş</th><th>Metre fiyatı</th><th>Durum</th><th>Eklenme</th><th aria-label="İşlemler">İşlemler</th></tr></thead><tbody>
                {filtered.map((fabric, index) => <tr key={fabric.id} data-testid={`row-admin-fabric-${fabric.id}`}>
                  <td><div className="table-name"><FabricPhoto fabric={fabric} index={index} alt="" /><span>{fabric.name}</span></div></td><td>{formatPrice(fabric.price)}</td><td><span className={`status-pill ${fabric.active ? '' : 'off'}`}>{fabric.active ? 'Yayında' : 'Taslak'}</span></td><td>{new Date(fabric.createdAt).toLocaleDateString('tr-TR')}</td>
                  <td><div className="table-controls"><button className="icon-button" onClick={() => { setEditing(fabric); setModalOpen(true); setActionError(''); }} aria-label={`${fabric.name} kumaşını düzenle`} data-testid={`button-edit-fabric-${fabric.id}`}><Pencil size={14} /></button><button className="icon-button" onClick={() => deleteFabric(fabric)} aria-label={`${fabric.name} kumaşını sil`} data-testid={`button-delete-fabric-${fabric.id}`}><Trash2 size={14} /></button></div></td>
                </tr>)}
              </tbody></table></div>}
      </section>
      <p className="muted" style={{ fontSize: 11, marginTop: 16, display: 'flex', gap: 7, alignItems: 'center' }}><ShieldCheck size={14} /> Metrikler toplu ve anonimdir; ziyaretçi kimliği veya IP adresi gösterilmez.</p>
    </main>
    {modalOpen && <FabricModal initial={editing ?? undefined} onClose={() => { setModalOpen(false); setEditing(null); }} onSave={saveFabric} pending={create.isPending || update.isPending} />}
    <Footer />
  </div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <RoutedErrorBoundary><CartProvider><Switch>
    <Route path="/" component={Home} />
    <Route path="/cart" component={CartPage} />
    <Route path="/login" component={LoginPage} />
    <Route path="/admin" component={AdminPage} />
    <Route component={NotFound} />
  </Switch></CartProvider></RoutedErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter>
      <Toaster />
    </TooltipProvider>
  </QueryClientProvider>;
}

export default App;
