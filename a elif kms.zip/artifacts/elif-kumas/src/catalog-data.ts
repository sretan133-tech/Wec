import type { Fabric as FabricRecord } from '@workspace/api-client-react';

export type CatalogFabric = FabricRecord & {
  category: string;
  isSample?: boolean;
};

const sampleRows: Array<{ category: string; name: string; description: string; price: number }> = [
  { category: 'Pamuklu', name: 'Pamuk Poplin · Kırık Beyaz', description: 'Gömlek, elbise ve günlük dikiş projeleri için tok, nefes alan pamuklu dokuma.', price: 189 },
  { category: 'Pamuklu', name: 'Müslin · Adaçayı', description: 'Yumuşak ve hafif çift kat dokusuyla bebek ürünleri ve rahat kıyafetler için.', price: 235 },
  { category: 'Pamuklu', name: 'Kanvas · Kum Beji', description: 'Çanta, kırlent ve dekoratif projelere uygun dayanıklı pamuklu kanvas.', price: 260 },
  { category: 'Pamuklu', name: 'Pamuk Saten · Gül Kurusu', description: 'Pamuk hissini saten yüzeyin zarif parlaklığıyla buluşturan yumuşak doku.', price: 295 },
  { category: 'Pamuklu', name: 'Poplin · Mavi Çizgi', description: 'İnce çizgili, hafif ve rahat poplin; gömlek ve yazlık parçalar için.', price: 215 },
  { category: 'Pamuklu', name: 'Pamuk Gabardin · Zeytin', description: 'Sık dokulu, formunu koruyan gabardin; pantolon ve ceket projelerine uygun.', price: 275 },

  { category: 'Keten', name: 'Doğal Keten · Ham', description: 'Doğal görünümlü yüzeyi ve serin tutan yapısıyla zamansız keten dokuma.', price: 390 },
  { category: 'Keten', name: 'Yıkamalı Keten · Taş', description: 'Yumuşak tuşeli, dökümlü ve günlük kullanıma uygun yıkamalı keten.', price: 420 },
  { category: 'Keten', name: 'Keten Karışımlı · Adaçayı', description: 'Keten görünümünü daha kolay şekil alan dengeli bir karışımla sunar.', price: 345 },
  { category: 'Keten', name: 'İri Dokuma Keten · Krem', description: 'Belirgin dokusu ve doğal tonu ile elbise, masa örtüsü ve ev tekstiline uygun.', price: 450 },
  { category: 'Keten', name: 'İnce Keten · Mavi', description: 'Hafif yazlık giysiler ve ferah gömlekler için ince keten dokuma.', price: 380 },
  { category: 'Keten', name: 'Keten Görünümlü Dokuma · Kül', description: 'Keten karakterli dokusu ve pratik kullanımıyla çok yönlü bir seçenek.', price: 299 },

  { category: 'Saten', name: 'Saten · Şampanya', description: 'Akışkan yüzeyi ve yumuşak parlaklığıyla özel gün tasarımlarına uygun.', price: 320 },
  { category: 'Saten', name: 'İpek Dokulu Saten · Gül', description: 'İpeksi dokunuşlu, zarif dökümlü ve ışığı güzel yansıtan saten.', price: 490 },
  { category: 'Saten', name: 'Likralı Saten · Gece', description: 'Esnek yapısı ve derin rengiyle elbise ve sahne kostümleri için.', price: 350 },
  { category: 'Saten', name: 'Mat Saten · Fildişi', description: 'Gösterişsiz, yumuşak mat yüzeyiyle bluz ve davet kıyafetlerine uygun.', price: 365 },
  { category: 'Saten', name: 'Düşes Saten · Bordo', description: 'Daha tok duruşlu ve belirgin parlak yüzeyli özel tasarım sateni.', price: 520 },
  { category: 'Saten', name: 'Çiçekli Saten · Pudra', description: 'Pudra tonları ve zarif çiçek deseniyle romantik, akışkan bir kumaş.', price: 395 },

  { category: 'Kadife', name: 'Fitilli Kadife · Tarçın', description: 'Belirgin fitilli yüzeyiyle ceket, pantolon ve aksesuar projelerine uygun.', price: 430 },
  { category: 'Kadife', name: 'Kadife · Petrol', description: 'Yumuşak havlı yüzeyi ve derin petrol tonuyla güçlü bir doku.', price: 475 },
  { category: 'Kadife', name: 'Esnek Kadife · Mürdüm', description: 'Rahat hareket sağlayan esnek yapısı ve zengin kadife dokusu.', price: 495 },
  { category: 'Kadife', name: 'Döşemelik Kadife · Zümrüt', description: 'Koltuk, puf ve kırlent projeleri için dolgun, dayanıklı kadife.', price: 560 },
  { category: 'Kadife', name: 'Kısa Havlı Kadife · Kum', description: 'Daha sakin bir parlaklık ve yumuşak dokunuş isteyenlere.', price: 420 },
  { category: 'Kadife', name: 'Parlak Kadife · Gece', description: 'Işığa göre tonu değişen yüzeyiyle sahne ve davet tasarımlarına uygun.', price: 510 },

  { category: 'Şifon', name: 'Şifon · Siyah', description: 'Hafif, yarı transparan ve akışkan şifon; katmanlı tasarımlar için.', price: 210 },
  { category: 'Şifon', name: 'Desenli Şifon · Bahar', description: 'Renkli çiçek desenleri ve hafif dökümüyle yazlık parçalara uygun.', price: 260 },
  { category: 'Şifon', name: 'Krep Şifon · Pudra', description: 'Hafif dokulu yüzeyi sayesinde dökümlü bluz ve elbiselerde güzel durur.', price: 275 },
  { category: 'Şifon', name: 'İpeksi Şifon · Krem', description: 'İpeksi hissi ve yumuşak hareketiyle zarif katmanlar için.', price: 295 },
  { category: 'Şifon', name: 'Puantiyeli Şifon · Lacivert', description: 'Klasik puantiye desenli hafif şifon; elbise ve fular projelerine uygun.', price: 260 },
  { category: 'Şifon', name: 'İnce Şifon · Lavanta', description: 'Pastel rengi ve uçuşan yapısıyla hafif yazlık tasarımlar için.', price: 225 },

  { category: 'Döşemelik', name: 'Döşemelik Dokuma · Kiremit', description: 'Kırlent, sandalye ve ev aksesuarlarında kullanılabilecek tok dokuma.', price: 520 },
  { category: 'Döşemelik', name: 'Koltuk Kumaşı · Antrasit', description: 'Sık dokulu ve sağlam yüzeyiyle yoğun kullanıma uygun döşemelik.', price: 590 },
  { category: 'Döşemelik', name: 'Duck Bezi · Doğal', description: 'Çanta, minder ve dekoratif ev tekstili için çok amaçlı kalın pamuklu.', price: 390 },
  { category: 'Döşemelik', name: 'Geometrik Döşemelik · Zeytin', description: 'Modern geometrik deseni ve tok yapısıyla mobilya yenilemeye uygun.', price: 610 },
  { category: 'Döşemelik', name: 'Su İtici Dış Mekân · Taş', description: 'Balkon minderleri ve dış mekân aksesuarları için pratik yüzey.', price: 540 },
  { category: 'Döşemelik', name: 'Kalın Dokuma · Vizon', description: 'Belirgin dokusu ve güçlü tutumuyla dekorasyon projelerine uygun.', price: 495 },

  { category: 'Desenli', name: 'Çiçek Bahçesi · Krem', description: 'Yumuşak zemin üzerine yayılan çiçek desenleriyle elbise ve ev tekstiline uygun.', price: 290 },
  { category: 'Desenli', name: 'Akdeniz Yaprakları · Yeşil', description: 'Canlı yaprak deseniyle ferah gömlek, etek ve dekoratif projeler için.', price: 310 },
  { category: 'Desenli', name: 'Ekose · Tarçın', description: 'Sıcak tonlu klasik ekose; gömlek, etek ve aksesuar projelerine uygun.', price: 270 },
  { category: 'Desenli', name: 'Minik Pötikare · Mavi', description: 'Küçük kare deseniyle gömlek, çocuk kıyafeti ve mutfak tekstiline uygun.', price: 255 },
  { category: 'Desenli', name: 'Geometrik · Toprak', description: 'Toprak tonlarında dengeli geometrik desen; modern projeler için.', price: 320 },
  { category: 'Desenli', name: 'Çizgili · Lacivert', description: 'Zamansız çizgileriyle gömlek, elbise ve çanta projelerine uygun.', price: 285 },

  { category: 'Örme', name: 'Penye · Ekru', description: 'Yumuşak ve esnek pamuklu penye; tişört ve rahat kıyafetler için.', price: 185 },
  { category: 'Örme', name: 'Süprem · Kömür', description: 'Günlük tişörtlerde tercih edilen hafif ve rahat süprem örme.', price: 205 },
  { category: 'Örme', name: 'Ribana · Krem', description: 'Esnek fitilli yapısıyla yaka, manşet ve rahat üst giyim projelerine uygun.', price: 240 },
  { category: 'Örme', name: 'İnterlok · Adaçayı', description: 'Daha tok ve düzgün yüzeyli örme kumaş; bebek ve günlük giyim için.', price: 260 },
  { category: 'Örme', name: 'Viskon Örme · Mürdüm', description: 'Yumuşak dökümlü, esnek viskon örme; elbise ve bluzlar için.', price: 295 },
  { category: 'Örme', name: 'Triko · Kum', description: 'Sıcak dokusu ve rahat esnemesiyle mevsimlik üst giyim projelerine uygun.', price: 340 },

  { category: 'Tül & Dantel', name: 'İnce Tül · Beyaz', description: 'Hafif ve transparan tül; katman, astar ve dekorasyon projeleri için.', price: 180 },
  { category: 'Tül & Dantel', name: 'Fransız Dantel · Ekru', description: 'İnce motifleri ve zarif görünümüyle özel tasarımlara uygun dantel.', price: 420 },
  { category: 'Tül & Dantel', name: 'Güpür Dantel · Krem', description: 'Belirgin kabartmalı motifleriyle elbise ve aksesuar detayları için.', price: 560 },
  { category: 'Tül & Dantel', name: 'Organze · Şampanya', description: 'Hafif parlak ve form tutan organze; dekoratif ve davet tasarımları için.', price: 230 },
  { category: 'Tül & Dantel', name: 'İşlemeli Tül · Pudra', description: 'İnce işlemeli dokusuyla özel gün ve katmanlı kıyafet tasarımlarına uygun.', price: 350 },
  { category: 'Tül & Dantel', name: 'File Tül · Siyah', description: 'Dengeli file dokusuyla kostüm, aksesuar ve dekoratif kullanımlar için.', price: 225 },
];

const sampleImages = ['/fabric-olive.png', '/fabric-terracotta.png', '/fabric-teal.png'];

export const demoCatalog: CatalogFabric[] = sampleRows.map((row, index) => ({
  id: -(index + 1),
  name: row.name,
  description: row.description,
  price: row.price,
  imageUrl: sampleImages[index % sampleImages.length],
  active: true,
  createdAt: '2026-01-01T00:00:00.000Z',
  category: row.category,
  isSample: true,
}));

const categoryMatchers: Array<{ category: string; keywords: RegExp }> = [
  { category: 'Tül & Dantel', keywords: /tül|tul|dantel|organze|güpür|gupur|file/ },
  { category: 'Döşemelik', keywords: /döşemelik|dosemelik|döşeme|doseme|koltuk|duck bezi|dış mekân|dis mekan/ },
  { category: 'Kadife', keywords: /kadife|fitilli/ },
  { category: 'Şifon', keywords: /şifon|sifon|krep şifon|krep sifon/ },
  { category: 'Saten', keywords: /saten|ipek/ },
  { category: 'Keten', keywords: /keten|linen/ },
  { category: 'Örme', keywords: /örme|orme|penye|süprem|suprem|ribana|interlok|triko/ },
  { category: 'Desenli', keywords: /desen|çiçek|cicek|ekose|pötikare|potikare|geometrik|çizgi|cizgi|puantiye/ },
  { category: 'Pamuklu', keywords: /pamuk|poplin|müslin|muslin|kanvas|gabardin/ },
];

export function inferFabricCategory(fabric: Pick<FabricRecord, 'name' | 'description'>): string {
  const searchable = `${fabric.name} ${fabric.description}`.toLocaleLowerCase('tr-TR');
  return categoryMatchers.find(({ keywords }) => keywords.test(searchable))?.category ?? 'Diğer';
}
