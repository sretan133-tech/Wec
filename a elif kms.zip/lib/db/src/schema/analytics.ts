import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, text } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const analyticsCountersTable = pgTable("analytics_counters", {
  key: text("key").primaryKey(),
  count: integer("count").notNull().default(0),
});

export const insertAnalyticsCounterSchema = createInsertSchema(
  analyticsCountersTable,
);
export type InsertAnalyticsCounter = z.infer<
  typeof insertAnalyticsCounterSchema
>;
export type AnalyticsCounter = typeof analyticsCountersTable.$inferSelect;
