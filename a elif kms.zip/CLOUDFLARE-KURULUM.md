# Elif Kumaş — Cloudflare Pages kurulumu

## Bu pakette ne değişti?
- Mevcut React/Vite arayüzü, katalog, sepet ve yönetim paneli kaynakları korunmuştur.
- Vite artık Cloudflare derleme ortamında PORT ve BASE_PATH değişkenleri verilmediğinde hata vermez.
- Cloudflare Pages için SPA yönlendirmesi ve `wrangler.toml` eklendi.
- API adresi `VITE_API_BASE_URL` ile ayarlanabilir.
- Türkçe sayfa dili ve temel SEO açıklaması düzenlendi.

## Cloudflare Pages'e bağlama
1. ZIP'i açıp içindeki tüm dosyaları bir GitHub deposuna yükleyin. Depo kökünde `package.json`, `pnpm-workspace.yaml` ve `wrangler.toml` bulunmalı.
2. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git bölümünden GitHub deposunu seçin.
3. Build ayarları:
   - Framework preset: `Vite` (veya None)
   - Root directory: `/` (depo kökü)
   - Build command: `pnpm --filter @workspace/elif-kumas run build`
   - Build output directory: `artifacts/elif-kumas/dist/public`
   - Node.js version: `22`
4. İlk dağıtımı başlatın. Sonra Pages projesi → Custom domains bölümünden satın aldığınız domaini ekleyin ve Cloudflare'ın DNS yönergelerini tamamlayın.

## Wrangler CLI ile dağıtım (isteğe bağlı)
Depo kökünde terminal açın:

```bash
pnpm install --no-frozen-lockfile
pnpm --filter @workspace/elif-kumas run build
npx wrangler pages deploy artifacts/elif-kumas/dist/public --project-name elif-kumas
```

> Bu proje Vite tabanlı bir **Pages sitesi** olduğu için komut `wrangler pages deploy` şeklindedir. `wrangler deploy` ise Worker dağıtımı içindir.

## Önemli: API / yönetim paneli
Bu kaynakta web arayüzünden ayrı bir Express API sunucusu vardır. API; PostgreSQL veritabanı ve Replit Object Storage sidecar servisini kullanıyor. Cloudflare Pages yalnızca web arayüzünü yayınlar; mevcut Express API'yi kendiliğinden çalıştırmaz. Bu nedenle API ayrıca uyumlu bir Node.js sunucusuna taşınmadan veya Cloudflare Workers/D1/R2 için ayrıca dönüştürülmeden canlı katalog, yönetici girişi, ürün ekleme/düzenleme, görsel yükleme ve istatistik özellikleri çalışmayacaktır. Backend kaynakları bu pakette silinmemiş veya değiştirilmemiştir.

API başka bir HTTPS alanında yayınlanırsa Cloudflare Pages projesinin Environment variables bölümüne `VITE_API_BASE_URL` ekleyin (ör. `https://api.siteniz.com`) ve yeniden dağıtın. API tarafında sitenizin origin'i için credentials destekli CORS ve aynı site kapsamındaki güvenli cookie ayarları bulunmalıdır.

## Güvenlik notu
`ELIF_ADMIN_USERNAME`, `ELIF_ADMIN_PASSWORD`, `SESSION_SECRET` ve `DATABASE_URL` gibi sırları GitHub'a veya frontend ortam değişkenlerine koymayın. Bunlar yalnızca backend sunucusunun gizli değişkenlerinde tutulmalıdır.
